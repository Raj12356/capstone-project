// lib/store.ts

/*export const store = {
  tasks: [] as {
    id: number;
    title: string;
    assignedTo: number;
    priority: string;
    status: string;
    dueDate: string;
  }[],*/

  /*comments: [] as {
    id: number;
    taskId: number;
    userId: number;
    message: string;
    createdAt: string;
  }[],
};*/